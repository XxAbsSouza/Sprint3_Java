import java.util.Scanner;

public class Sprint3 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int qtdEquipe, qtdCombate, notaDesign, pontosCombate = 0;
		String resultadoCombate;
		
		System.out.print("Informe a quantidade de equipes: ");
		qtdEquipe = teclado.nextInt();
		
		int[] listaClassificacao = new int [qtdEquipe];
		int[] pontosTotais = new int [qtdEquipe];
		
		for(int equipes = 1; equipes <= qtdEquipe; equipes++) {
			System.out.print("\nEquipe #" + equipes);
			System.out.println();
			System.out.print("Quantos combates essa equipe realizou? ");
			qtdCombate = teclado.nextInt();
			System.out.print("Qual foi a nota do design do rob� da equipe " + equipes + "? ");
			notaDesign = teclado.nextInt();
			
			// Calculo de pontos de cada equipe
			
			for(int i = 0; i < listaClassificacao.length; i++) {
				listaClassificacao[i] = 0;
				System.out.print("Combate " + (i+1) + " obteve: (digite APENAS V para vit�ria ou D para derrota ou E para empate) ");
				resultadoCombate = teclado.next();
				if(resultadoCombate.equals("V")) {
					pontosCombate += 5;
				}else if(resultadoCombate.equals("D")) {
					pontosCombate += 0;
				}else if(resultadoCombate.equals("E")) {
					pontosCombate += 3;
				}
				pontosTotais[i] = pontosCombate;
			
			}
			System.out.println("Pontos totais da equipe: " + pontosCombate);
		}	
			//Desempate por design de robo
//			for (int i = 0; i < listaClassificacao.length; i++) {
//				if (pontosTotais[i] == ) {
//					
//				}
//			}
//			
		
		System.out.println();
		System.out.println("Lista de Classificacao:");
		
		for (int i = 0; i < listaClassificacao.length; i++) {
			System.out.println();
			System.out.println("Equipe #" + (i + 1) );
			
			
		}
		
			
		
	}
}

